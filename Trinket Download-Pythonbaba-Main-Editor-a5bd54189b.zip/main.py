# Online Python compiler (interpreter) to run Python online.
# Write Python 3 code in this online editor and run it.
# Get started with interactive Python!
# Supports Python Modules: builtins, math,pandas, scipy 
# matplotlib.pyplot, numpy, operator, processing, pygal, random, 
# re, string, time, turtle, urllib.request
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import scipy as sp
x = [1,6,3]
y = [5,9,4]

x2 = [1,2,3]
y2 = [10,14,12]

x3=[2,44,55]
y3=[45,4,32]

x4=[3,57,22]
y4=[55,33,2]

plt.plot(x, y, label='First Line')
plt.plot(x2, y2, label='Second Line')
plt.plot(x3, y3, label='Third line')
plt.plot(x4, y4, label='fourth Line')
plt.xlabel('Plot Number')
plt.ylabel('Important var')
plt.title('Different plots')
plt.legend()
plt.show()
